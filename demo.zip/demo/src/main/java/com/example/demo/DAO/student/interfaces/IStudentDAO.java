package com.example.demo.DAO.student.interfaces;

import com.example.demo.model.Student;

import java.util.List;

public interface IStudentDAO {
    public Student insertStudent(Student student);

    public Student getStudent(int id);

    public Student updateStudent(Student student);

    public Student deleteStudent(int id);

    public List<Student> getAll();

}
