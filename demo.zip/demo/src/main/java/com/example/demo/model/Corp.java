package com.example.demo.model;

import java.util.List;

public class Corp {
    Integer id;
    Integer number;
    Integer hospitalId;

    public void setId(Integer id) {
        this.id = id;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public void setHospitalId(Integer hospitalId) {
        this.hospitalId = hospitalId;
    }

    public Integer getId() {

        return id;
    }

    public Integer getNumber() {
        return number;
    }

    public Integer getHospitalId() {
        return hospitalId;
    }

    public Corp(Integer id, Integer number, Integer hospitalId) {
        this.id = id;
        this.number = number;
        this.hospitalId = hospitalId;
    }
}
