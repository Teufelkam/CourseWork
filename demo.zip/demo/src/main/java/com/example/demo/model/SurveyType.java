package com.example.demo.model;

public enum SurveyType {
    OPERATION, EXITING, OPENING
}
