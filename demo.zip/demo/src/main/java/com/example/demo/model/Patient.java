package com.example.demo.model;

public class Patient {
    Integer id;
    String name;
    String surname;
    Doctor clinicDoctorId;
    Doctor hospitalDoctorId;
    Cot cot;

    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setClinicDoctorId(Doctor clinicDoctorId) {
        this.clinicDoctorId = clinicDoctorId;
    }

    public void setHospitalDoctorId(Doctor hospitalDoctorId) {
        this.hospitalDoctorId = hospitalDoctorId;
    }

    public void setCot(Cot cot) {
        this.cot = cot;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public Doctor getClinicDoctorId() {
        return clinicDoctorId;
    }

    public Doctor getHospitalDoctorId() {
        return hospitalDoctorId;
    }

    public Cot getCot() {
        return cot;
    }

    public Patient(Integer id, String name, String surname, Doctor clinicDoctorId, Doctor hospitalDoctorId, Cot cot) {

        this.id = id;
        this.name = name;
        this.surname = surname;
        this.clinicDoctorId = clinicDoctorId;
        this.hospitalDoctorId = hospitalDoctorId;
        this.cot = cot;
    }
}
