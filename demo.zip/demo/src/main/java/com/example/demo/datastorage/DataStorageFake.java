package com.example.demo.datastorage;

import com.example.demo.model.Cabinet;
import com.example.demo.model.Chair;
import com.example.demo.model.Student;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Configuration
public class DataStorageFake {
    public List<Chair> chairs = new ArrayList<>(
            Arrays.asList(
                    new Chair(1, "Software engineering", "SE"),
                    new Chair(2, "Computer engineering", "CE"),
                    new Chair(3, "BDFU engineering", "BDFUE"),
                    new Chair(4, "MPUIK engineering", "POD")
            ));


    public List<Chair> getChairs() {
        return chairs;
    }


    private List<Student> students = new ArrayList<>();

    {
        students.add(new Student(1, "Ivan", "Ivanov", this.getChairs().get(1)));
        students.add(new Student(2, "Ivan", "Muroniv", this.getChairs().get(1)));
        students.add(new Student(2, "Ivan22", "Muroniv22", this.getChairs().get(2)));
        students.add(new Student(2, "Ivan33", "Muroniv33", this.getChairs().get(3)));
        students.add(new Student(2, "Ivan44", "Muroniv44", this.getChairs().get(0)));
    }

    public List<Student> getStudents() {
        return students;
    }

    private List<Cabinet> cabinets = new ArrayList<>(
            Arrays.asList(
                    new Cabinet(1, 101, 1, new ArrayList<>()),
                    new Cabinet(1, 102, 1, new ArrayList<>()),
                    new Cabinet(1, 103, 1, new ArrayList<>()),
                    new Cabinet(1, 103, 1, new ArrayList<>()),
                    new Cabinet(1, 103, 1, new ArrayList<>())
            ));


    public List<Cabinet> getCabinets() {
        return cabinets;
    }


}
