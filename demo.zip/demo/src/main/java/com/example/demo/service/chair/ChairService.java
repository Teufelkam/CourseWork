package com.example.demo.service.chair;

import com.example.demo.DAO.chair.interfaces.IChairDAO;
import com.example.demo.model.Chair;
import com.example.demo.service.chair.interfaces.IChairService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChairService implements IChairService {
    @Autowired
    IChairDAO chairDAO;

    @Override
    public Chair insertChair(Chair chair) {
        return chairDAO.insertChair(chair);
    }

    @Override
    public Chair getChair(int id) {
        return chairDAO.getChair(id);
    }

    @Override
    public Chair updateChair(Chair chair) {
        return chairDAO.updateChair(chair);
    }

    @Override
    public Chair deleteChair(int id) {
        return chairDAO.deleteChair(id);
    }

    @Override
    public List<Chair> getAll() {
        return chairDAO.getAll();
    }

    @Override
    public Chair getChairByName(String chair) {
        List<Chair> all = chairDAO.getAll();
        return all.stream()
                .filter(x -> x.getName().equals(chair))
                .findFirst()
                .get();

    }
}
