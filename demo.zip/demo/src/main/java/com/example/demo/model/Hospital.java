package com.example.demo.model;

import java.util.List;

public class Hospital {
    Integer id;
    String name;
    String adress;

    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public Integer getId() {

        return id;
    }

    public String getName() {
        return name;
    }

    public String getAdress() {
        return adress;
    }

    public Hospital(Integer id, String name, String adress) {

        this.id = id;
        this.name = name;
        this.adress = adress;
    }
}
