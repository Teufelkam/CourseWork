package com.example.demo.model;

import java.util.Date;

public class HospitalSurvey {
    Integer id;
    HospitalHistory hospitalHistory;
    Doctor doctor;
    SurveyType type;
    Date date;
    String description;

    public Integer getId() {
        return id;
    }

    public HospitalHistory getHospitalHistory() {
        return hospitalHistory;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public SurveyType getType() {
        return type;
    }

    public Date getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

    public void setId(Integer id) {

        this.id = id;
    }

    public void setHospitalHistory(HospitalHistory hospitalHistory) {
        this.hospitalHistory = hospitalHistory;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public void setType(SurveyType type) {
        this.type = type;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public HospitalSurvey(Integer id, HospitalHistory hospitalHistory, Doctor doctor, SurveyType type, Date date, String description) {

        this.id = id;
        this.hospitalHistory = hospitalHistory;
        this.doctor = doctor;
        this.type = type;
        this.date = date;
        this.description = description;
    }
}
