package com.example.demo.model;

public class Worker {
    Integer id;
    String name;
    String surname;
    Hospital hospital;
    Clinic clinic;

    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setHospital(Hospital hospital) {
        this.hospital = hospital;
    }

    public void setClinic(Clinic clinic) {
        this.clinic = clinic;
    }

    public Integer getId() {

        return id;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public Hospital getHospital() {
        return hospital;
    }

    public Clinic getClinic() {
        return clinic;
    }

    public Worker(Integer id, String name, String surname, Hospital hospital, Clinic clinic) {

        this.id = id;
        this.name = name;
        this.surname = surname;
        this.hospital = hospital;
        this.clinic = clinic;
    }
}
