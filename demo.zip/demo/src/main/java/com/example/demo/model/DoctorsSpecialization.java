package com.example.demo.model;

public enum DoctorsSpecialization {
    SURGEON, NEUROLOGIST, THERAPIST
}
