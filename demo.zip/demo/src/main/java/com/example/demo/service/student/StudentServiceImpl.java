package com.example.demo.service.student;

import com.example.demo.DAO.student.interfaces.IStudentDAO;
import com.example.demo.model.Chair;
import com.example.demo.model.Student;
import com.example.demo.service.student.interfaces.IStudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class StudentServiceImpl implements IStudentService {
    @Autowired
    IStudentDAO studentDAO;

    @Override
    public Student insertStudent(Student student) {
        return studentDAO.insertStudent(student);
    }

    @Override
    public Student getStudent(int id) {
        return studentDAO.getStudent(id);
    }

    @Override
    public Student updateStudent(Student student) {
        return studentDAO.updateStudent(student);
    }

    @Override
    public Student deleteStudent(int id) {
        return studentDAO.deleteStudent(id);
    }

    @Override
    public List<Student> getAll() {
        return studentDAO.getAll();
    }

    @Override
    public List<Student> getStudentByChair(Chair chair) {
        return studentDAO.getAll().stream()
                .filter(el -> el.getChair().getId() == chair.getId())
                .collect(Collectors.toList());
    }



    @Override
    public Chair bestChair(){
        List<Student> list = studentDAO.getAll();
        Chair bestChair = list.stream()
                .collect(Collectors.groupingBy(Student::getChair, Collectors.counting()))
                .entrySet()
                .stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .collect(Collectors.toList()).get(0).getKey();




        return bestChair;
        }

}
