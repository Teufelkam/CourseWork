package com.example.demo.service.chair.interfaces;

import com.example.demo.model.Chair;

import java.util.List;

public interface IChairService {

    public Chair insertChair(Chair chair);

    public Chair getChair(int id);

    public Chair updateChair(Chair chair);

    public Chair deleteChair(int id);

    public List<Chair> getAll();

    Chair getChairByName(String chair);
}
