package com.example.demo.model;

public class ClinicHistory {
    Integer id;
    Patient patient;
    Clinic clinic;

    public ClinicHistory(Integer id, Patient patient, Clinic clinic) {
        this.id = id;
        this.patient = patient;
        this.clinic = clinic;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public void setClinic(Clinic clinic) {
        this.clinic = clinic;
    }

    public Integer getId() {

        return id;
    }

    public Patient getPatient() {
        return patient;
    }

    public Clinic getClinic() {
        return clinic;
    }
}
