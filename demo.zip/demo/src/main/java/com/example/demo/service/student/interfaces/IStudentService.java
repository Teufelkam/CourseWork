package com.example.demo.service.student.interfaces;

import com.example.demo.model.Chair;
import com.example.demo.model.Student;

import java.util.List;

public interface IStudentService {

     Student insertStudent(Student student);

     Student getStudent(int id);

     Student updateStudent(Student student);

     Student deleteStudent(int id);

     List<Student> getAll();

     List<Student> getStudentByChair(Chair chair);

     Chair bestChair();
}
