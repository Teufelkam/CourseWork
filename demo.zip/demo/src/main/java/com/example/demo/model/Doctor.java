package com.example.demo.model;

import java.util.Date;

public class Doctor {
    Integer id;
    String name;
    String surname;
    DoctorsSpecialization type;
    Date careerStartYear;
    ScienceRank scienceRank;

    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setType(DoctorsSpecialization type) {
        this.type = type;
    }

    public void setCareerStartYear(Date careerStartYear) {
        this.careerStartYear = careerStartYear;
    }

    public void setScienceRank(ScienceRank scienceRank) {
        this.scienceRank = scienceRank;
    }

    public Integer getId() {

        return id;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public DoctorsSpecialization getType() {
        return type;
    }

    public Date getCareerStartYear() {
        return careerStartYear;
    }

    public ScienceRank getScienceRank() {
        return scienceRank;
    }

    public Doctor(Integer id, String name, String surname, DoctorsSpecialization type, Date careerStartYear, ScienceRank scienceRank) {

        this.id = id;
        this.name = name;
        this.surname = surname;
        this.type = type;
        this.careerStartYear = careerStartYear;
        this.scienceRank = scienceRank;
    }
}
