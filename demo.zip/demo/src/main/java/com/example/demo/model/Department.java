package com.example.demo.model;

import java.util.List;

public class Department {
    Integer id;
    DepartmentsType type;
    Corp corp;
    List<Doctor> doctorList;
    List<Worker> workerList;

    public void setId(Integer id) {
        this.id = id;
    }

    public void setType(DepartmentsType type) {
        this.type = type;
    }

    public void setCorp(Corp corp) {
        this.corp = corp;
    }

    public void setDoctorList(List<Doctor> doctorList) {
        this.doctorList = doctorList;
    }

    public void setWorkerList(List<Worker> workerList) {
        this.workerList = workerList;
    }

    public Integer getId() {

        return id;
    }

    public DepartmentsType getType() {
        return type;
    }

    public Corp getCorp() {
        return corp;
    }

    public List<Doctor> getDoctorList() {
        return doctorList;
    }

    public List<Worker> getWorkerList() {
        return workerList;
    }

    public Department(Integer id, DepartmentsType type, Corp corp, List<Doctor> doctorList, List<Worker> workerList) {

        this.id = id;
        this.type = type;
        this.corp = corp;
        this.doctorList = doctorList;
        this.workerList = workerList;
    }
}
