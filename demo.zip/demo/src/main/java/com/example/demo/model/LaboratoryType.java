package com.example.demo.model;

public enum LaboratoryType {
    PHYSICAL, CHEMICAL, PSYHIOLOGICAL
}
