package com.example.demo.model;

public enum ScienceRank {
    DOCTOR, CANDIDATE
}
