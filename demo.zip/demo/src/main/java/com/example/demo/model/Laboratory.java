package com.example.demo.model;

import java.util.List;

public class Laboratory {
    Integer id;
    LaboratoryType type;
    List<Hospital> hospitalList;

    public void setId(Integer id) {
        this.id = id;
    }

    public void setType(LaboratoryType type) {
        this.type = type;
    }

    public void setHospitalList(List<Hospital> hospitalList) {
        this.hospitalList = hospitalList;
    }

    public Integer getId() {

        return id;
    }

    public LaboratoryType getType() {
        return type;
    }

    public List<Hospital> getHospitalList() {
        return hospitalList;
    }

    public Laboratory(Integer id, LaboratoryType type, List<Hospital> hospitalList) {

        this.id = id;
        this.type = type;
        this.hospitalList = hospitalList;
    }
}
