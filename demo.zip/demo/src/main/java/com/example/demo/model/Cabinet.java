package com.example.demo.model;

import java.util.List;

public class Cabinet {
    Integer id;
    Integer number;
    Integer clinicId;
    List<Doctor> doctorList;

    public Cabinet(Integer id, Integer number, Integer clinicId, List<Doctor> doctorList) {
        this.id = id;
        this.number = number;
        this.clinicId = clinicId;
        this.doctorList = doctorList;
    }

    public Integer getId() {
        return id;
    }

    public Integer getNumber() {
        return number;
    }

    public Integer getClinicId() {
        return clinicId;
    }

    public List<Doctor> getDoctorList() {
        return doctorList;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public void setClinicId(Integer clinicId) {
        this.clinicId = clinicId;
    }

    public void setDoctorList(List<Doctor> doctorList) {
        this.doctorList = doctorList;
    }
}
