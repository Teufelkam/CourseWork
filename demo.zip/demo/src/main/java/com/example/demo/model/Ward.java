package com.example.demo.model;

import java.util.List;

public class Ward {
    Integer id;
    Integer number;
    Department department;

    public Ward(Integer id, Integer number, Department department) {
        this.id = id;
        this.number = number;
        this.department = department;
    }

    public Integer getId() {
        return id;
    }

    public Integer getNumber() {
        return number;
    }

    public Department getDepartment() {
        return department;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }
}
