package com.example.demo.DAO.chair.interfaces;

import com.example.demo.model.Cabinet;

import java.util.List;

public interface ICabinetDAO {

    public Cabinet getCabinet(int id);

    public List<Cabinet> getAll();
}
