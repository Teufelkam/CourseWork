package com.example.demo.DAO.chair;

import com.example.demo.DAO.chair.interfaces.ICabinetDAO;
import com.example.demo.datastorage.DataStorageFake;
import com.example.demo.model.Cabinet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CabinetDAOFakeImpl implements ICabinetDAO{
    @Autowired
    DataStorageFake dataStorage;

    @Override
    public Cabinet getCabinet(int id) {
        return dataStorage.getCabinets().stream()
                .filter(el -> el.getId() == id)
                .findFirst().orElse(null);
    }

    public List<Cabinet> getAll() {
        return dataStorage.getCabinets();
    }
}
