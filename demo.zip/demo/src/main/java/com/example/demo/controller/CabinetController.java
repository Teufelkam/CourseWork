package com.example.demo.controller;

import com.example.demo.model.Cabinet;
import com.example.demo.service.cabinet.interfaces.ICabinetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CabinetController {
    @Autowired
    ICabinetService cabinetService;

    @RequestMapping("/cabinets")
    public List<Cabinet> showCabinets() {
        return cabinetService.getAll();
    }
}
