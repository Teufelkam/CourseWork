package com.example.demo.service.cabinet.interfaces;

import com.example.demo.model.Cabinet;

import java.util.List;

public interface ICabinetService {
    public Cabinet getCabinet(int id);

    public List<Cabinet> getAll();
}
