package com.example.demo.model;

public class Cot {
    Integer id;
    Integer number;
    Ward ward;

    public void setId(Integer id) {
        this.id = id;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public void setWard(Ward ward) {
        this.ward = ward;
    }

    public Integer getId() {

        return id;
    }

    public Integer getNumber() {
        return number;
    }

    public Ward getWard() {
        return ward;
    }

    public Cot(Integer id, Integer number, Ward ward) {

        this.id = id;
        this.number = number;
        this.ward = ward;
    }
}
