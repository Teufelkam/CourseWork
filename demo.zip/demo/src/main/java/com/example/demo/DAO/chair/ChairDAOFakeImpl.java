package com.example.demo.DAO.chair;

import com.example.demo.DAO.chair.interfaces.IChairDAO;
import com.example.demo.datastorage.DataStorageFake;
import com.example.demo.model.Chair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ChairDAOFakeImpl implements IChairDAO {

    @Autowired
    DataStorageFake dataStorage;


    @Override
    public Chair insertChair(Chair chair) {
        dataStorage.getChairs().add(chair);
        return chair;
    }

    @Override
    public Chair getChair(int id) {
        return dataStorage.getChairs().stream()
                .filter(el -> el.getId() == id)
                .findFirst().orElse(null);
    }

    @Override
    public Chair updateChair(Chair chair) {
        for (Chair chair1 : dataStorage.getChairs()) {
            if (chair1.getId() == chair.getId()) {
                chair1.setName(chair.getName());
                chair1.setAbr(chair.getAbr());
                break;
            }
        }
        return chair;
    }

    @Override
    public Chair deleteChair(int id) {
        Chair chair = dataStorage.getChairs()
                .stream()
                .filter(el -> el.getId() == id)
                .findFirst()
                .get();
        int index = dataStorage.getChairs().indexOf(chair);
        dataStorage.getChairs().remove(index);
        return chair;
    }

    @Override
    public List<Chair> getAll() {
        return dataStorage.getChairs();
    }
}
