package com.example.demo.model;

import java.util.Date;

public class ClinicSurvey {
    Integer id;
    ClinicHistory clinicHistory;
    Doctor doctor;
    SurveyType type;
    Date date;
    String description;

    public void setId(Integer id) {
        this.id = id;
    }

    public void setClinicHistory(ClinicHistory clinicHistory) {
        this.clinicHistory = clinicHistory;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public void setType(SurveyType type) {
        this.type = type;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getId() {

        return id;
    }

    public ClinicHistory getClinicHistory() {
        return clinicHistory;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public SurveyType getType() {
        return type;
    }

    public Date getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

    public ClinicSurvey(Integer id, ClinicHistory clinicHistory, Doctor doctor, SurveyType type, Date date, String description) {

        this.id = id;
        this.clinicHistory = clinicHistory;
        this.doctor = doctor;
        this.type = type;
        this.date = date;
        this.description = description;
    }
}
