package com.example.demo.model;

public enum DepartmentsType {
    SURGICAL, THERAPEUTIC, NEUROLOGICAL,
}
