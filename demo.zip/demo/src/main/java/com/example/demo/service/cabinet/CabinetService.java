package com.example.demo.service.cabinet;

import com.example.demo.DAO.chair.interfaces.ICabinetDAO;
import com.example.demo.model.Cabinet;
import com.example.demo.service.cabinet.interfaces.ICabinetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CabinetService implements ICabinetService{

    @Autowired
    ICabinetDAO cabinetDAO;

    @Override
    public Cabinet getCabinet(int id) {
        return cabinetDAO.getCabinet(id);
    };

    @Override
    public List<Cabinet> getAll() {
        return cabinetDAO.getAll();
    };

}
