package com.example.demo.DAO.student;

import com.example.demo.DAO.student.interfaces.IStudentDAO;
import com.example.demo.datastorage.DataStorageFake;
import com.example.demo.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class StudentDAOFakeImpl implements IStudentDAO {


    @Autowired
    DataStorageFake dataStorage;


    @Override
    public Student insertStudent(Student student) {
        dataStorage.getStudents().add(student);
        return student;
    }

    @Override
    public Student getStudent(int id) {
        return dataStorage.getStudents().stream()
                .filter(el -> el.getId() == id)
                .findFirst().orElse(null);
    }

    @Override
    public Student updateStudent(Student student) {
        for (Student student1 : dataStorage.getStudents()) {
            if (student1.getId() == student.getId()) {
                student1.setFirstName(student.getFirstName());
                student1.setSecondName(student.getSecondName());
                student1.setChair(student.getChair());
                break;
            }
        }
        return student;
    }

    @Override
    public Student deleteStudent(int id) {
        Student student = dataStorage.getStudents()
                .stream()
                .filter(el -> el.getId() == id)
                .findFirst()
                .get();
        dataStorage.getStudents().remove(student);
        return student;
    }

    @Override
    public List<Student> getAll() {
        return dataStorage.getStudents();
    }


}
