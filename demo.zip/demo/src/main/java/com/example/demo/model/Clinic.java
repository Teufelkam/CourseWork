package com.example.demo.model;

public class Clinic {
    Integer id;
    Hospital hospital;
    String name;

    public Clinic(Integer id, Hospital hospital, String name) {
        this.id = id;
        this.hospital = hospital;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public Hospital getHospital() {
        return hospital;
    }

    public String getName() {
        return name;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setHospital(Hospital hospital) {
        this.hospital = hospital;
    }

    public void setName(String name) {
        this.name = name;
    }
}
