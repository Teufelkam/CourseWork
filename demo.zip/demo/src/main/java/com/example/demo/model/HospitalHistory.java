package com.example.demo.model;

import java.util.List;

public class HospitalHistory {
    Integer id;
    Patient patient;
    Hospital hospital;

    public void setId(Integer id) {
        this.id = id;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public void setHospital(Hospital hospital) {
        this.hospital = hospital;
    }

    public Integer getId() {

        return id;
    }

    public Patient getPatient() {
        return patient;
    }

    public Hospital getHospital() {
        return hospital;
    }

    public HospitalHistory(Integer id, Patient patient, Hospital hospital) {

        this.id = id;
        this.patient = patient;
        this.hospital = hospital;
    }
}
